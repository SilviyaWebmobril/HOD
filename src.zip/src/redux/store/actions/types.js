export const ADD_LOCATION = "ADD LOCATION";
export const ADD_USER_DATA = "USER DATA";