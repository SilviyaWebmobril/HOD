import React, { Component } from 'react';
import {
    View,
    Image,
    Text,
    TouchableOpacity,
    SafeAreaView,
} from 'react-native';
import After_SplashStyle from './After_SplashStyle';

export default class After_Splash extends Component {
    static navigationOptions = ({ navigation }) => ({
        header: null
    });

    onLogin = () => {
        this.props.navigation.navigate('Login');
    };
    onCreate_Account = () => {
        this.props.navigation.navigate('Create_Account');
    };

    render() {
        return (
            <SafeAreaView style={After_SplashStyle.container}>
             
           
               <Image source={require('../../Assets/after-splash-top.png')} style={After_SplashStyle.after_splash_top} />
             
              <View style={After_SplashStyle.after_splash_bottom}>

                  <TouchableOpacity  onPress={() => this.onLogin()} style={After_SplashStyle.LoginBtn}>
                    <Text style={After_SplashStyle.btntxt}>LOGIN</Text>
                  </TouchableOpacity>
                  <View style={{margin:25}}> 
                  <Text style={{color:'#808080',fontWeight: 'bold',fontSize: 17,}}>OR</Text>
                  </View>
                  <TouchableOpacity  onPress={() => this.onCreate_Account()} style={After_SplashStyle.CreateAccountBtn}>
                    <Text style={{...After_SplashStyle.btntxt,color:'#48241e',}}>CREATE ACCOUNT</Text>
                </TouchableOpacity> 
        
              </View>
              
            </SafeAreaView>
        );
    }
}
