import React, { Component } from 'react';
import { createStackNavigator, createAppContainer } from 'react-navigation';
import After_Splash from '../After_Splash/After_Splash';
import Login from '../Login/Login';
import OTP from '../OTP/OTP'
import Create_Account from '../Create_Account/Create_Account';
import Search_Location from '../Search_Location/Search_Location';
import { fromRight } from 'react-navigation-transitions';

const MyApp = createStackNavigator({
    After_Splash ,
    Login,
    Create_Account,
    OTP,
    Search_Location
  },{
    initialRouteName: 'After_Splash',
    transitionConfig: () => fromRight(500),
  },)
  
  export default createAppContainer(MyApp)
