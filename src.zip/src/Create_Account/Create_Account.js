import React, { Component } from 'react';


import {
    View,
    Image,
    Text,
    TextInput,
    TouchableOpacity,
    SafeAreaView,
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scrollview';
import Create_AccountStyle from './Create_AccountStyle';

export default class Create_Account extends Component {
    
    static navigationOptions = ({ navigation }) => ({
        title: 'CREATE ACCOUNT',
        headerStyle: {
            height: 60,
            backgroundColor: '#FD8D45',
        },
        headerTitleStyle: {
            color: 'white',
            alignSelf: 'center',
            textAlign: 'center',
            flex: 1,
            fontSize: 17,
        },
        headerTintColor: 'white',
        headerRight: (<View></View>)
    });
    onLogin = () => {
        this.props.navigation.navigate('Login');
    };
    onContinue = ()=>{
        this.props.navigation.navigate('OTP');
    }
    state = { isFocused1: false,isFocused2: false,isFocused3: false };//isFocused1 is for textinput1, isFocused2 is for textinput2, isFocused3 is for textinput3
   
    render() {
        
        return (
            <SafeAreaView style={Create_AccountStyle.container}>
              <KeyboardAwareScrollView  showsVerticalScrollIndicator={false} >
                   <View style={Create_AccountStyle.Create_Accounttop}>
                   <Image source={require('../../Assets/logo1.png')}/>
                   </View>
                  <View style={Create_AccountStyle.Create_Accountbottom}>
                      
                  <View style={{width:'90%',flexDirection:'column',justifyContent:'flex-start',alignItems:'flex-start'}}>
                      <Text style={{color:'#808080',fontWeight: 'bold',fontSize: 17,}}>
                          Name*
                      </Text>
                   <TextInput 
                    onFocus={()=>this.setState({isFocused1:true})}
                    onBlur={()=>this.setState({isFocused1:false})}
                   style={[Create_AccountStyle.txtInput,{
                    borderColor: this.state.isFocused1
                        ? '#FD8D45'
                        : 'black',
                    borderWidth: this.state.isFocused1
                    ? 1.5 
                    : 1,
                }]}
                   placeholder="Enter Name" placeholderTextColor='#898785'
                   returnKeyType = { "next" }
                   onSubmitEditing={() => { this.secondTextInput.focus(); }}
                  />
                    <Text style={{color:'#808080',fontWeight: 'bold',fontSize: 17,marginTop:5}}>
                          Mobile*
                      </Text>
                      <TextInput 
                        onFocus={()=>this.setState({isFocused2:true})}
                        onBlur={()=>this.setState({isFocused2:false})}
                        style={[Create_AccountStyle.txtInput,{
                            borderColor: this.state.isFocused2
                                ? '#FD8D45'
                                : 'black',
                            borderWidth: this.state.isFocused2
                            ? 1.5 
                            : 1,
                        }]}
                   placeholder="Enter mobile number" placeholderTextColor='#898785'
                   ref={(input) => { this.secondTextInput = input; }}
                   returnKeyType = { "next" }
                   onSubmitEditing={() => { this.thirdTextInput.focus(); }}
                  />
                    <Text style={{color:'#808080',fontWeight: 'bold',fontSize: 17,marginTop:10}}>
                          Refferal Code(optional)*Terms Apply
                      </Text>
                      <TextInput 
                  onFocus={()=>this.setState({isFocused3:true})}
                  onBlur={()=>this.setState({isFocused3:false})}
                  style={[Create_AccountStyle.txtInput,{
                      borderColor: this.state.isFocused3
                          ? '#FD8D45'
                          : 'black',
                      borderWidth: this.state.isFocused3
                      ? 1.5 
                      : 1,
                  }]}
                   placeholder="Enter Refferal Code" placeholderTextColor='#898785'
                   ref={(input) => { this.thirdTextInput = input; }}
            
                  />
                  </View>
                <View style={{marginTop:10,width:'90%',flexDirection:'column',justifyContent:'center',alignItems:'center'}}>

                
                  <TouchableOpacity  onPress={() => this.onContinue()} style={Create_AccountStyle.ContinueBtn}>
                    <Text style={Create_AccountStyle.btntxt}>CONTINUE</Text>
                  </TouchableOpacity>
                  <View style={{width:'100%',justifyContent:'center',alignItems: 'center'}}> 
                  <Text style={{color:'#808080',margin:5,fontWeight: 'bold',fontSize: 17,}}>OR</Text>
                  </View>
                  <TouchableOpacity  onPress={() => this.onLogin()} style={Create_AccountStyle.LoginBtn}>
                    <Text style={{...Create_AccountStyle.btntxt,color:'#48241e',}}>LOGIN</Text>
                </TouchableOpacity> 
        
              </View>
              </View>
              </KeyboardAwareScrollView>
            </SafeAreaView>
        );
    }
}