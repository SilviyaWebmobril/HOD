import React, { Component } from 'react';
import {
    View,
    Image,
    Text,
    TextInput,
    TouchableOpacity,
    SafeAreaView,
    Alert
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scrollview';
import OTPStyle from './OTPStyles';



export default class OTP extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: 'OTP',
        headerStyle: {
            height: 60,
            backgroundColor: '#FD8D45',
        },
        headerTitleStyle: {
            color: 'white',
            alignSelf: 'center',
            textAlign: 'center',
            flex: 1,
            fontSize: 17,
        },
        headerTintColor: 'white',
        headerRight: (<View></View>)
    });
    onSubmit = () => {
        this.props.navigation.navigate('Create_Account');
    };
    constructor(props) {
        super(props);
        this.state = { seconds: 60 };
      }
      tick() {
        this.state.seconds>0?this.setState(prevState => ({seconds: prevState.seconds - 1})): (clearInterval(this.interval),Alert.alert("OTP Expired Please RESEND"));
    }
    onStartTimer(){
        clearInterval(this.interval);
        this.setState({seconds:60});
        this.interval = setInterval(() => this.tick(), 1000);
    }
      componentDidMount() {
        this.interval = setInterval(() => this.tick(), 1000);
      }
      componentWillUnmount() {
        clearInterval(this.interval);
      }
    render() {
        return (
            <SafeAreaView style={OTPStyle.container}>
                   <KeyboardAwareScrollView  showsVerticalScrollIndicator={false} >
       
               <View style={OTPStyle.Logintop}>
                   <Image source={require('../../Assets/logo1.png')}/>
                   </View>
              <View style={OTPStyle.bottom}>
                  <Text style={{color:'black',fontWeight: 'bold',fontSize: 20,marginBottom:10}}>OTP</Text>
                  <Text style={{color:'#898785',fontWeight: 'bold',fontSize: 17,marginBottom:10}}>Phone Number Verification</Text>
                  <View style={OTPStyle.circle}>
                      <Text style={OTPStyle.Timertxt}>{this.state.seconds}</Text>
                      </View>
                  <View style={{width:'90%',flexDirection:'row',justifyContent:'flex-start',alignItems:'flex-start'}}>
                      <Text style={{color:'black',fontWeight: 'bold',fontSize: 14,}}>OTP</Text>
                  </View>
              <TextInput 
                   style={OTPStyle.txtInput}
                   placeholder="Enter OTP" placeholderTextColor='#898785'
                  />
                  <TouchableOpacity onPress={() => this.onStartTimer()} style={{width:'90%',flexDirection:'row',justifyContent:'flex-end',alignItems:'flex-end'}}>
                      <Text style={{color:'#FD8D45',fontWeight: 'bold',fontSize: 14,textDecorationLine: 'underline'}}>Resend</Text>
                  </TouchableOpacity>
                  <TouchableOpacity  onPress={() => this.onSubmit()} style={OTPStyle.LoginBtn}>
                    <Text style={OTPStyle.btntxt}>SUBMIT</Text>
                  </TouchableOpacity>
              </View>
              </KeyboardAwareScrollView>
            </SafeAreaView>
        );
    }
}