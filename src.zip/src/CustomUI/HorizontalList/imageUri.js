const images = [
    {
        id:1,
        image_url:require('../../../Assets/swt1.jpeg'),
        text:"House Of Sweets"
    },
    {
        id:2,
        image_url:require('../../../Assets/swt2.jpeg'),
        text:"House Of Salads"
    },
    {
        id:3,
        image_url:require('../../../Assets/swt3.jpg'),
        text:"House Of Dairy"
    },
    {
        id:4,
        image_url:require('../../../Assets/swt4.jpg'),
        text:"House Of Cakes"
    },
    {
        id:5,
        image_url:require('../../../Assets/swt5.jpeg'),
        text:"House Of Buscuits"
    },
    {
        id:6,
        image_url:require('../../../Assets/swt6.jpeg'),
        text:"House Of Sweets"
    },
    {
        id:7,
        image_url:require('../../../Assets/swt7.jpeg'),
        text:"House Of Salads"
    },
    {
        id:8,
        image_url:require('../../../Assets/swt8.jpeg'),
        text:"House Of Cakes"
    },
    {
        id:9,
        image_url:require('../../../Assets/swt9.jpeg'),
        text:"House Of Buscuits"
    }
];

export  {images};