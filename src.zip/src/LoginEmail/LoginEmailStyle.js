import { StyleSheet,Dimensions } from 'react-native';
const LoginEmailStyle = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor:'#ffffff',
        margin:10
      },
});


export default LoginEmailStyle;