import React, { Component } from 'react';
import {
    View,
    Image,
    Text,
    TextInput,
    TouchableOpacity,
    SafeAreaView,
    
} from 'react-native';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scrollview';
import LoginStyle from './LoginStyle';

export default class Login extends Component {
    static navigationOptions = ({ navigation }) => ({
        title: 'LOGIN WITH OTP',
        headerStyle: {
            height: 60,
            backgroundColor: '#FD8D45',
        },
        headerTitleStyle: {
            color: 'white',
            alignSelf: 'center',
            textAlign: 'center',
            flex: 1,
            fontSize: 17,
        },
        headerTintColor: 'white',
        headerRight: (<View></View>)
    });
    state={isFocuse:false}
    onLogin=()=>{
   this.props.navigation.navigate('OTP');
    };
    onCreate_Account = () => {
        this.props.navigation.navigate('Create_Account');
    };
    render() {
        return (
            <SafeAreaView style={LoginStyle.container}>
                   <KeyboardAwareScrollView  showsVerticalScrollIndicator={false} >
              <View style={LoginStyle.Logintop}>
                   <Image source={require('../../Assets/logo1.png')}/>
                   </View>
              <View style={LoginStyle.bottom}>
                  <View style={{width:'90%',flexDirection:'row',justifyContent:'flex-start',alignItems:'flex-start'}}>
                      <Text style={{color:'#808080',fontWeight: 'bold',fontSize: 17,}}>
                          Enter your number
                      </Text>
                  </View>
              <TextInput 
               onFocus={()=>this.setState({isFocused:true})}
               onBlur={()=>this.setState({isFocused:false})}
               style={[LoginStyle.txtInput,{
                   borderColor: this.state.isFocused
                       ? '#FD8D45'
                       : 'black',
                   borderWidth: this.state.isFocused
                   ? 1.5 
                   : 1,
               }]}
                  
                   placeholder="Enter mobile number" placeholderTextColor='#898785'
                   keyboardType='numeric'
                  />
                  <TouchableOpacity  onPress={() => this.onLogin()} style={LoginStyle.LoginBtn}>
                    <Text style={LoginStyle.btntxt}>CONTINUE</Text>
                  </TouchableOpacity>
                  <View style={{margin:5}}> 
                  <Text style={{color:'#808080',fontWeight: 'bold',fontSize: 17,}}>OR</Text>
                  </View>
                  <TouchableOpacity  onPress={() => this.onCreate_Account()} style={LoginStyle.CreateAccountBtn}>
                    <Text style={{...LoginStyle.btntxt,color:'#48241e',}}>CREATE ACCOUNT</Text>
                </TouchableOpacity> 
        
              </View>
              </KeyboardAwareScrollView>
            </SafeAreaView>
        );
    }
}


