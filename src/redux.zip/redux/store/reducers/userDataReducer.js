import { ADD_USER_DATA } from '../actions/types';


const initialState = {
    userdata:[]
}
 const userDataReducer = (state = initialState,action)  => {

    const newState =  action.payload;
    console.log("new state",newState);


    switch(action.type){
        case ADD_USER_DATA:
           
           
            return{
                ...state,
                userdata:newState
            }
            default:
                 return state;
    }
 

}


export default userDataReducer;